# Portfolio Website.
Web Portfolio to showcase projects and skills in better manner. 

######  https://mmrraju.github.io/mmrraju.github.io./.

------------------------------------------------------------------
To setup the project on your local machine:

1. Click on `Fork`.
2. Go to your fork and `clone` the project to your local machine.
3. `git clone https://github.com/mmrraju/mmrraju.github.io..git
